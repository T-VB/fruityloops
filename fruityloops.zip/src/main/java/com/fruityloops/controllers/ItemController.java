package com.fruityloops.controllers;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fruityloops.models.Item;

//create Controller 
@Controller
public class ItemController {
	@RequestMapping("/")
	public String index(Model model) {
		
		ArrayList<Item> fruits = new ArrayList<Item>();
		fruits.add(new Item("Kiwi", 1.59));
		fruits.add(new Item("Mango", 2.09));
		fruits.add(new Item("Pineapple", 4.99));
		fruits.add(new Item("Grapes", 3.29));
		
		//add fruits view model
		model.addAttribute("fruits", fruits);
		
		return "index.jsp";
	}
}
